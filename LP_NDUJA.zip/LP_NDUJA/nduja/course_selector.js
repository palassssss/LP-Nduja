// Selezione automatica argomenti corso
console.log('📚 Course Selector Attivo');

let config = {
  autoNext: true
};

chrome.storage.local.get(['autoNext'], (result) => {
  config = { ...config, ...result };
  
  if (config.autoNext) {
    autoSelectNext();
  }
});

function autoSelectNext() {
  console.log('🔍 Ricerca prossimo argomento...');

  // Attendi caricamento pagina
  setTimeout(() => {
    const container = document.querySelector('.scorm_content, .course-content');
    
    if (!container) {
      console.log('❌ Container non trovato');
      return;
    }

    // Cerca argomenti
    const items = container.querySelectorAll('a[href*="lesson_student_view"], a[href*="videolezioni"]');
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      // Cerca icone di completamento
      const completed = item.querySelector('.completed, .done, [class*="check"]');
      const notCompleted = !completed;
      
      if (notCompleted) {
        console.log('✅ Prossimo argomento da completare trovato');
        item.click();
        return;
      }
    }

    console.log('ℹ️ Tutti gli argomenti completati');
  }, 1000);
}