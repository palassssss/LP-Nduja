// AutoPlay per il player vecchio
console.log('🎬 Mercatorum AutoPlay - Player Vecchio Attivo');

let config = {
  autoplay: true,
  muted: false,
  autoNext: true
};

// Carica configurazione
chrome.storage.local.get(['autoplay', 'muted', 'autoNext'], (result) => {
  config = { ...config, ...result };
  console.log('⚙️ Config caricata:', config);
  if (config.autoplay) {
    initAutoPlay();
  }
});

function initAutoPlay() {
  console.log('🚀 Inizializzazione AutoPlay...');

  // Attendi che il video sia caricato
  const checkVideo = setInterval(() => {
    const video = document.querySelector('video');
    
    if (video) {
      clearInterval(checkVideo);
      console.log('✅ Video trovato!');
      
      // Imposta volume
      video.muted = config.muted;
      video.volume = config.muted ? 0 : 0.5;
      
      // Avvia video
      video.play().then(() => {
        console.log('▶️ Video avviato automaticamente');
      }).catch(err => {
        console.error('❌ Errore avvio video:', err);
      });

      // Listener per la fine del video
      video.addEventListener('ended', () => {
        console.log('✅ Video terminato');
        if (config.autoNext) {
          goToNextVideo();
        }
      });

      // Listener per errori
      video.addEventListener('error', (e) => {
        console.error('❌ Errore video:', e);
        if (config.autoNext) {
          setTimeout(goToNextVideo, 2000);
        }
      });
    }
  }, 500);

  // Timeout di sicurezza
  setTimeout(() => clearInterval(checkVideo), 10000);
}

function goToNextVideo() {
  console.log('⏭️ Passaggio al video successivo...');
  
  // Cerca il pulsante "Avanti" o "Next"
  const nextButtons = [
    document.querySelector('a[title*="Avanti"]'),
    document.querySelector('a[title*="Next"]'),
    document.querySelector('button[title*="Avanti"]'),
    document.querySelector('button[title*="Next"]'),
    document.querySelector('.lp_navigation_elem a:last-child'),
    document.querySelector('a[onclick*="next"]')
  ];

  for (const btn of nextButtons) {
    if (btn && btn.offsetParent !== null) {
      console.log('🔘 Pulsante Next trovato, click...');
      btn.click();
      return;
    }
  }

  // Se non trova il pulsante, prova con la lista argomenti
  const items = document.querySelectorAll('.scorm_item_list a');
  const currentUrl = window.location.href;
  
  for (let i = 0; i < items.length; i++) {
    if (items[i].classList.contains('active') || items[i].href === currentUrl) {
      if (items[i + 1]) {
        console.log('📋 Prossimo argomento trovato nella lista');
        items[i + 1].click();
        return;
      }
    }
  }

  console.log('ℹ️ Nessun video successivo trovato - Fine corso?');
}

// Aggiungi indicatore visivo
const indicator = document.createElement('div');
indicator.innerHTML = '🤖 AutoPlay ATTIVO';
indicator.style.cssText = `
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #4CAF50;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  font-family: Arial, sans-serif;
  font-size: 14px;
  font-weight: bold;
  z-index: 10000;
  box-shadow: 0 2px 5px rgba(0,0,0,0.3);
`;
document.body.appendChild(indicator);

// Nascondi dopo 3 secondi
setTimeout(() => {
  indicator.style.transition = 'opacity 0.5s';
  indicator.style.opacity = '0';
  setTimeout(() => indicator.remove(), 500);
}, 3000);