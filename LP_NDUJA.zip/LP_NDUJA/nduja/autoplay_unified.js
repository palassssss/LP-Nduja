// Mercatorum AutoPlay - Sequenziale + Popups + Auto-Resume dopo Reload

(async function () {
  'use strict';

  document.addEventListener("click", function () { }, { once: true });
  if (document.body) document.body.click();

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const log = (...args) => console.log("[SEQ]", ...args);

  await sleep(2000);

  // ===========================
  //   GESTIONE STATO & RESUME
  // ===========================
  const STATE_KEY = 'mercatorum_autoplay_state';
  
  const saveState = (state) => {
    sessionStorage.setItem(STATE_KEY, JSON.stringify({
      ...state,
      timestamp: Date.now()
    }));
  };

  const loadState = () => {
    try {
      const data = sessionStorage.getItem(STATE_KEY);
      if (!data) return null;
      const state = JSON.parse(data);
      // Scarta stato vecchio (>10 minuti)
      if (Date.now() - state.timestamp > 600000) {
        sessionStorage.removeItem(STATE_KEY);
        return null;
      }
      return state;
    } catch {
      return null;
    }
  };

  const clearState = () => {
    sessionStorage.removeItem(STATE_KEY);
  };

  // ===========================
  //   AUTO-CLICK POPUP "OK"
  // ===========================
  const autoClickOK = () => {
    const allButtons = document.querySelectorAll('button');
    for (let btn of allButtons) {
      const text = btn.textContent.trim().toUpperCase();
      if (text === 'OK' || text === 'RIPROVA' || text === 'RICARICA') {
        const parent = btn.closest('[role="dialog"], [class*="modal"], [class*="popup"], .swal');
        if (parent) {
          log("🤖 Auto-click su popup:", text);
          log("💾 Salvo stato prima del reload...");
          
          // Salva stato corrente
          saveState({
            mode: 'resume',
            url: window.location.href
          });
          
          setTimeout(() => btn.click(), 100);
          return true;
        }
      }
    }
    return false;
  };

  const observer = new MutationObserver(() => {
    autoClickOK();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  log("✅ Observer attivo per auto-click su popup");

  // ===========================
  //   CONFIG BASE
  // ===========================
  const PLAYBACK_SPEED = 1.0;
  const DELAY_TENDINA = () => 8000 + Math.random() * 2000;
  const EXTRA_BUFFER   = () => 35000 + Math.random() * 10000;
  const STEP_WAIT      = () => 28000 + Math.random() * 4000;
  const DONE = 100;

  // ===========================
  //   POPUP SIMPATICI
  // ===========================
  const FRASI_SIMPATICHE = [
    "🏖️ I ciucci si mbriganu e 'i varrili si sgàscianu\n(Gli asini si imbrigliano e i barili si rompono\n- Chi è stupido combina disastri)",
    "🌶️ Nduja supremacy",
    "🚓 Lu gàbbu cògghia e la jestiìma no\n(Il gabbo raccoglie e la gelosia no\n- L'invidia non porta nulla)",
    "🏝️ La Calabria è la regione più bella",
    "😴 VA CURCATI!!!!\n(Vai a dormire!)",
    "🎓 Laurea speedrun any%",
    "🤖 Si propriu nu cunnu\n(Sei proprio uno stupido)",
    "☕ L'acqua guglia e u porcu è alla muntagna\n(L'acqua bolle e il maiale è in montagna\n- Non fasciarti la testa)",
    "🌴 Cu' prima non pensa, all'urtimu suspira\n(Chi prima non pensa, alla fine sospira\n- Pensa prima di agire)",
    "🎪 Cu' ava cchjù santi va in paradisu\n(Chi ha più santi va in paradiso\n- Le conoscenze contano)",
    "🎭 Megghju n'aiutu ca centu cunsigghj\n(Meglio un aiuto che cento consigli)",
    "🏆 Cu' mangia pocu mangia sempra\n(Chi mangia poco mangia sempre,\nchi mangia tanto scoppia presto)",
    "🌊 Mala non fara e paura non avira\n(Male non fare e paura non avere)",
    "🍝 Cu' dassa 'a strata vecchja pp'a nova\n(Chi lascia la strada vecchia per la nuova\nsa cosa lascia ma non sa cosa trova)"
  ];

  const POP = (() => {
    const host = document.createElement('div');
    host.style.position = 'fixed';
    host.style.right = '24px';
    host.style.bottom = '24px';
    host.style.zIndex = '2147483647';
    const shadow = host.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = `
      :host { all: initial; }
      .stack { display: flex; flex-direction: column; gap: 12px; max-width: 520px; }
      .toast {
        opacity: 0; transform: translateY(10px);
        padding: 16px 18px; border-radius: 14px; color: #fff;
        font: 700 16px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, Arial;
        box-shadow: 0 14px 36px rgba(0,0,0,.40);
        background: rgba(17,17,17,.97); white-space: pre-line; cursor: default;
        letter-spacing: .2px; word-break: break-word;
      }
      .toast[role="alert"] { outline: none; }
      .in  { opacity: 1; transform: translateY(0); transition: opacity .22s ease, transform .22s ease; }
      .out { opacity: 0; transform: translateY(10px); transition: opacity .18s ease, transform .18s ease; }
      .close {
        position: absolute; top: 8px; right: 12px;
        font: 700 16px/1 system-ui, -apple-system, "Segoe UI", Roboto, Arial;
        color: rgba(255,255,255,.85); cursor: pointer; user-select: none;
      }
      .wrap { position: relative; }
    `;
    const stack = document.createElement('div');
    stack.className = 'stack';
    shadow.append(style, stack);
    document.body.appendChild(host);

    const _sleep = ms => new Promise(r => setTimeout(r, ms));
    const randPhrase = () => FRASI_SIMPATICHE[Math.floor(Math.random() * FRASI_SIMPATICHE.length)];

    function trimIfNeeded(max = 5) {
      while (stack.children.length > max) {
        stack.firstChild?.remove();
      }
    }

    async function showPopup(msg, color = 'rgba(17,17,17,.97)', ms = 15000) {
      const wrap = document.createElement('div');
      wrap.className = 'wrap';

      const el = document.createElement('div');
      el.className = 'toast';
      el.setAttribute('role', 'alert');
      el.style.background = color;
      el.textContent = msg;

      const x = document.createElement('div');
      x.className = 'close';
      x.textContent = '×';

      wrap.appendChild(el);
      wrap.appendChild(x);
      stack.appendChild(wrap);
      trimIfNeeded();

      const dismiss = () => {
        el.classList.remove('in'); el.classList.add('out');
        setTimeout(() => wrap.remove(), 240);
      };

      el.addEventListener('click', dismiss);
      x.addEventListener('click', dismiss);

      await _sleep(20);
      el.classList.add('in');

      await _sleep(ms);
      dismiss();
    }

    let _ticker = null;
    function startTicker(baseMs = 25000, jitterMs = 5000) {
      stopTicker();
      const tick = async () => {
        try { await showPopup(randPhrase(), 'rgba(0,0,0,.95)', 12000); } catch {}
        const next = baseMs + Math.floor((Math.random() * 2 - 1) * jitterMs);
        _ticker = setTimeout(tick, Math.max(8000, next));
      };
      tick();
    }
    function stopTicker() {
      if (_ticker) { clearTimeout(_ticker); _ticker = null; }
    }

    return { showPopup, randPhrase, startTicker, stopTicker };
  })();

  // ===========================
  //   CHECK RESUME
  // ===========================
  const savedState = loadState();
  if (savedState && savedState.mode === 'resume') {
    log("🔄 Ripresa dopo reload!");
    POP.showPopup("🔄 Riprendo da dove ero...", "rgba(33,150,243,.97)", 6000);
    clearState(); // Pulisci stato
    
    // Aspetta che la pagina sia pronta
    await sleep(3000);
    
    // Riavvia il video corrente
    const video = await (async () => {
      for (let i = 0; i < 40; i++) {
        const v = document.querySelector('#video');
        if (v) return v;
        await sleep(500);
      }
      return null;
    })();
    
    if (video) {
      log("✅ Video trovato, riprendo riproduzione");
      video.muted = true;
      try {
        await video.play();
        video.playbackRate = PLAYBACK_SPEED;
        log("✅ Video riavviato");
        POP.showPopup("✅ Video riavviato!", "rgba(76,175,80,.97)", 5000);
      } catch (e) {
        log("⚠️ Errore riavvio:", e.message);
      }
    }
    
    // Termina qui, non rifare tutto il corso
    log("✅ Resume completato, script in attesa");
    POP.startTicker(25000, 5000);
    return;
  }

  POP.showPopup("🚀 Avvio autoplay", "rgba(33,150,243,.97)", 6000);
  POP.startTicker(25000, 5000);

  // ===========================
  //   SELETTORI & HELPERS
  // ===========================
  const SEL_MACRO_BLOCK = "div.flex-wrap.bg-platform-secondary-light";
  const SEL_ARROW_PATH  = 'path[id="chevron-down-Filled_1_"]';
  const SEL_HEADER      = "div.cursor-pointer.relative.align-middle";
  const SEL_LESSON      = "div.mb-2";
  const EXCLUDE_RE      = /(Obiettivi|Test di fine lezione|Dispensa)/i;

  const waitFor = async (sel, timeout = 10000) => {
    const begin = performance.now();
    while (performance.now() - begin < timeout) {
      const el = document.querySelector(sel);
      if (el) return el;
      await sleep(250);
    }
    return null;
  };

  const safeClick = el => {
    if (!el) return;
    el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  };

  const getClickTarget = b => {
    const arrow = b.querySelector(SEL_ARROW_PATH);
    if (arrow) return arrow.closest("div");
    const header = b.querySelector(SEL_HEADER);
    if (header) return header;
    return b;
  };

  const getProgressPct = root => {
    if (!root) return 0;
    const bar = root.querySelector("div.bg-platform-green");
    if (bar && bar.style.width && bar.style.width.includes("%")) {
      return parseInt(bar.style.width);
    }
    const lab = root.querySelector('div[class*="w-1/12"]') || root.querySelector("div.text-xs");
    if (lab) {
      const m = lab.textContent.match(/(\d+)\s*%/);
      if (m) return parseInt(m[1]);
    }
    return 0;
  };

  const parseDurationSecs = root => {
    const d = root.querySelector("div.text-sm");
    if (!d) return 0;
    const parts = d.textContent.trim().split(":").map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return 0;
  };

  const findContainer = e => {
    if (!e) return null;
    if (e.querySelector(SEL_LESSON)) return e;
    const divs = e.querySelectorAll("div");
    for (let i = 0; i < divs.length; i++) {
      if (divs[i].querySelector(SEL_LESSON)) return divs[i];
    }
    let s = e.nextElementSibling;
    while (s) {
      if (s.querySelector(SEL_LESSON)) return s;
      s = s.nextElementSibling;
    }
    return null;
  };

  const collectLessons = c => {
    if (!c) return [];
    const all = Array.from(c.querySelectorAll(SEL_LESSON));
    const filtered = all.filter(t => !EXCLUDE_RE.test(t.textContent));
    return filtered.map(t => ({
      title: t.textContent.trim(),
      root: t.closest("div.w-full") || t.closest("div.mb-2").parentElement
    }));
  };

  // ===========================
  //   PLAY LESSONS
  // ===========================
  const playLessons = async list => {
    log("Sottocategoria con " + list.length + " lezioni");

    for (let idx = 0; idx < list.length; idx++) {
      const l = list[idx];
      const pct = () => getProgressPct(l.root);
      const initialPct = pct();

      log(`[${idx + 1}/${list.length}] ${l.title.substring(0, 40)} - ${initialPct}%`);
      POP.showPopup("▶️ " + l.title.substring(0, 40), "rgba(76,175,80,.97)", 8000);

      if (initialPct >= DONE) {
        log("  Gia completata");
        POP.showPopup("✅ Già completata", "rgba(76,175,80,.97)", 5000);
        continue;
      }

      l.root.scrollIntoView({ block: "center" });
      await sleep(500);
      safeClick(l.root);
      await sleep(2000);

      const video = await waitFor("#video", 20000);
      if (!video) {
        log("  Player non trovato");
        POP.showPopup("❌ Player non trovato", "rgba(244,67,54,.97)", 7000);
        continue;
      }

      video.muted = true;

      log("  Avvio video...");
      try {
        await video.play();
        video.playbackRate = PLAYBACK_SPEED;
        log("  Video avviato a velocita normale");
        POP.showPopup("🎬 Video avviato", "rgba(76,175,80,.97)", 6000);
      } catch (e) {
        log("  ERRORE play: " + e.message);
        POP.showPopup("⚠️ Errore play", "rgba(255,152,0,.97)", 7000);
        continue;
      }

      let dur = (video.duration && !isNaN(video.duration)) ? video.duration : parseDurationSecs(l.root);
      if (!dur || dur <= 0) dur = 60;

      const realDuration = dur / PLAYBACK_SPEED;
      const firstWait = (realDuration * 1000) + EXTRA_BUFFER();

      log("  Durata: " + dur + "s");
      log("  Attesa: " + (firstWait / 1000).toFixed(0) + "s");

      await sleep(firstWait);

      let waited = 0;
      const maxLimit = Math.max(firstWait * 3, firstWait + 300000);

      while (pct() < DONE && waited < maxLimit) {
        const currentPct = pct();
        log("  " + currentPct + "% - attendo 30s");

        const waitTime = STEP_WAIT();
        await sleep(waitTime);
        waited += waitTime;

        if (video.paused) {
          log("  Video in pausa, riavvio...");
          try {
            await video.play();
            video.playbackRate = PLAYBACK_SPEED;
          } catch { }
        }
      }

      const finalPct = pct();
      if (finalPct >= DONE) {
        log("  COMPLETATA " + finalPct + "%");
        POP.showPopup("✅ Completata " + finalPct + "%", "rgba(76,175,80,.97)", 7000);
        POP.showPopup(POP.randPhrase(), "rgba(0,0,0,.95)", 10000);
      } else {
        log("  Timeout al " + finalPct + "%");
        POP.showPopup("⏳ Timeout al " + finalPct + "%", "rgba(255,152,0,.97)", 7000);
      }
    }
  };

  // ===========================
  //   NAV: SUB & MACRO
  // ===========================
  const sub = async h => {
    safeClick(getClickTarget(h));
    await sleep(DELAY_TENDINA());
    const c = findContainer(h.parentElement);
    if (!c) {
      log("Nessuna lezione trovata");
      POP.showPopup("ℹ️ Nessuna lezione trovata", "rgba(255,152,0,.97)", 7000);
      return;
    }
    await playLessons(collectLessons(c));
  };

  const mac = async m => {
    safeClick(getClickTarget(m));
    await sleep(DELAY_TENDINA());
    const done = new Set();

    while (true) {
      const all = Array.from(m.querySelectorAll(SEL_HEADER));
      const subs = all.filter(h => h !== getClickTarget(m) && !done.has(h));
      if (subs.length === 0) break;

      for (let i = 0; i < subs.length; i++) {
        done.add(subs[i]);
        await sub(subs[i]);
      }
    }
  };

  // ===========================
  //   MAIN
  // ===========================
  const macros = Array.from(document.querySelectorAll(SEL_MACRO_BLOCK));
  log("Trovate " + macros.length + " macrocategorie");

  for (let i = 0; i < macros.length; i++) {
    log(`\n=== Macro ${i + 1}/${macros.length} ===`);
    macros[i].scrollIntoView({ block: "center" });
    await mac(macros[i]);
  }

  log("\nFine");
  POP.showPopup("🎉 COMPLETATO", "rgba(76,175,80,.97)", 8000);
  clearState(); // Pulisci stato finale
})();