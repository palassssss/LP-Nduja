// Mercatorum AutoPlay - Con Test di Fine Lezione
(async function () {
  'use strict';
  
  // ===========================
  //   UTILS
  // ===========================
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const log = (...args) => console.log("[AUTO]", ...args);
  
  // Click iniziale per sbloccare autoplay
  document.addEventListener("click", function () {}, { once: true });
  if (document.body) document.body.click();
  
  await sleep(1500);
  
  // ===========================
  //   GESTIONE STATO
  // ===========================
  const STATE_KEY = 'merc_state';
  
  const saveState = (state) => {
    sessionStorage.setItem(STATE_KEY, JSON.stringify({
      ...state,
      timestamp: Date.now()
    }));
  };
  
  const loadState = () => {
    try {
      const data = sessionStorage.getItem(STATE_KEY);
      if (!data) return null;
      const state = JSON.parse(data);
      if (Date.now() - state.timestamp > 600000) {
        sessionStorage.removeItem(STATE_KEY);
        return null;
      }
      return state;
    } catch {
      return null;
    }
  };
  
  const clearState = () => sessionStorage.removeItem(STATE_KEY);
  
  // ===========================
  //   AUTO-CLICK POPUP
  // ===========================
  const autoClickOK = () => {
    const buttons = document.querySelectorAll('button');
    for (let btn of buttons) {
      const text = btn.textContent.trim().toUpperCase();
      if (['OK', 'RIPROVA', 'RICARICA', 'CHIUDI'].includes(text)) {
        const parent = btn.closest('[role="dialog"], [class*="modal"], [class*="popup"], .swal');
        if (parent) {
          log("Auto-click popup:", text);
          log("Salvo stato e attendo 40s prima del restart...");
          saveState({ mode: 'restart', url: window.location.href });
          setTimeout(() => btn.click(), 100);
          return true;
        }
      }
    }
    return false;
  };
  
  new MutationObserver(autoClickOK).observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // ===========================
  //   CONFIG
  // ===========================
  const PLAYBACK_SPEED = 1.0;
  const OBIETTIVO_WAIT = 1500;
  const AFTER_LAST_OBIETTIVO = 20000;
  const AFTER_VIDEO = 20000;
  const AFTER_TEST = 10000;
  const EXTRA_BUFFER = () => 30000 + Math.random() * 8000;
  const STEP_WAIT = () => 25000 + Math.random() * 3000;
  const DONE = 100;
  
  const SEL_MACRO = "div.flex-wrap.bg-platform-secondary-light";
  const SEL_ARROW = 'path[id="chevron-down-Filled_1_"]';
  const SEL_HEADER = "div.cursor-pointer.relative.align-middle";
  const SEL_LESSON = "div.mb-2";
  const EXCLUDE_RE = /Dispensa/i; // Solo Dispensa ora
  
  // ===========================
  //   HELPERS
  // ===========================
  const waitFor = async (sel, timeout = 10000) => {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const el = document.querySelector(sel);
      if (el) return el;
      await sleep(250);
    }
    return null;
  };
  
  const click = el => el?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
  
  const getClickTarget = b => {
    const arrow = b.querySelector(SEL_ARROW);
    if (arrow) return arrow.closest("div");
    return b.querySelector(SEL_HEADER) || b;
  };
  
  const getProgress = root => {
    if (!root) return 0;
    const bar = root.querySelector("div.bg-platform-green");
    if (bar?.style.width?.includes("%")) {
      return parseInt(bar.style.width);
    }
    const label = root.querySelector('div[class*="w-1/12"]') || root.querySelector("div.text-xs");
    if (label) {
      const m = label.textContent.match(/(\d+)\s*%/);
      if (m) return parseInt(m[1]);
    }
    return 0;
  };
  
  const getDuration = root => {
    const d = root.querySelector("div.text-sm");
    if (!d) return 0;
    const parts = d.textContent.trim().split(":").map(Number);
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return 0;
  };
  
  const findContainer = e => {
    if (!e) return null;
    if (e.querySelector(SEL_LESSON)) return e;
    for (let div of e.querySelectorAll("div")) {
      if (div.querySelector(SEL_LESSON)) return div;
    }
    let s = e.nextElementSibling;
    while (s) {
      if (s.querySelector(SEL_LESSON)) return s;
      s = s.nextElementSibling;
    }
    return null;
  };
  
  const isObiettivo = (lesson) => {
    return /^Obiettivi$/i.test(lesson.title.trim());
  };
  
  const isTest = (lesson) => {
    return /Test di fine lezione/i.test(lesson.title.trim());
  };
  
  const collectLessons = c => {
    if (!c) return [];
    return Array.from(c.querySelectorAll(SEL_LESSON))
      .filter(t => !EXCLUDE_RE.test(t.textContent))
      .map(t => ({
        title: t.textContent.trim(),
        root: t.closest("div.w-full") || t.closest("div.mb-2").parentElement
      }));
  };
  
  // ===========================
  //   CHECK RESTART
  // ===========================
  const savedState = loadState();
  if (savedState?.mode === 'restart') {
    log("🔄 Rilevato crash/reload - RESTART COMPLETO");
    clearState();
    
    log("⏳ Attesa 40 secondi per stabilizzazione...");
    await sleep(40000);
    
    log("✅ Riavvio script da capo...");
  }
  
  log("🚀 Avvio autoplay");
  
  // ===========================
  //   FASE 1: APERTURA COMPLETA
  // ===========================
  const openEverything = async () => {
    log("=== FASE 1: APERTURA TOTALE ===");
    
    const macros = Array.from(document.querySelectorAll(SEL_MACRO));
    log(`Trovate ${macros.length} macrocategorie`);
    
    log("Apertura di tutte le macrocategorie...");
    for (let macro of macros) {
      macro.scrollIntoView({ block: "center" });
      await sleep(100);
      click(getClickTarget(macro));
    }
    
    log("Attesa apertura macrocategorie (5s)...");
    await sleep(5000);
    
    log("Apertura di tutti i sottocapitoli...");
    let totalSubs = 0;
    
    for (let macro of macros) {
      const subHeaders = Array.from(macro.querySelectorAll(SEL_HEADER))
        .filter(h => h !== getClickTarget(macro));
      
      totalSubs += subHeaders.length;
      
      for (let subHeader of subHeaders) {
        subHeader.scrollIntoView({ block: "center" });
        await sleep(50);
        click(getClickTarget(subHeader));
      }
    }
    
    log(`Aperti ${totalSubs} sottocapitoli totali`);
    log("Attesa apertura sottocapitoli (8s)...");
    await sleep(8000);
    
    log("✅ Apertura completata!");
    return macros;
  };
  
  // ===========================
  //   FASE 2: SCANSIONE COMPLETA
  // ===========================
  const scanAll = async (macros) => {
    log("\n=== FASE 2: SCANSIONE COMPLETA ===");
    
    const allObiettivi = [];
    const allVideoTasks = [];
    const allTests = [];
    
    for (let i = 0; i < macros.length; i++) {
      const macro = macros[i];
      
      const subHeaders = Array.from(macro.querySelectorAll(SEL_HEADER))
        .filter(h => h !== getClickTarget(macro));
      
      for (let j = 0; j < subHeaders.length; j++) {
        const subHeader = subHeaders[j];
        
        const container = findContainer(subHeader.parentElement);
        if (!container) continue;
        
        const lessons = collectLessons(container);
        
        const obiettivi = lessons.filter(l => isObiettivo(l));
        const tests = lessons.filter(l => isTest(l));
        const videos = lessons.filter(l => !isObiettivo(l) && !isTest(l));
        
        // TUTTI gli obiettivi
        for (let obj of obiettivi) {
          allObiettivi.push({
            macroIndex: i,
            subIndex: j,
            lesson: obj
          });
        }
        
        // TUTTI i test
        for (let test of tests) {
          allTests.push({
            macroIndex: i,
            subIndex: j,
            lesson: test
          });
        }
        
        // Solo video incompleti
        const incompleteVideos = videos.filter(l => getProgress(l.root) < DONE);
        if (incompleteVideos.length > 0) {
          allVideoTasks.push({
            macroIndex: i,
            subIndex: j,
            macro,
            subHeader,
            lessons: incompleteVideos
          });
        }
      }
    }
    
    log(`✅ Trovati ${allObiettivi.length} obiettivi totali`);
    log(`✅ Trovati ${allVideoTasks.length} sottocapitoli con video mancanti`);
    log(`✅ Trovati ${allTests.length} test di fine lezione`);
    
    return { allObiettivi, allVideoTasks, allTests };
  };
  
  // ===========================
  //   FASE 3: OBIETTIVI
  // ===========================
  const completeObiettivi = async (obiettivi) => {
    if (obiettivi.length === 0) {
      log("\n=== FASE 3: NESSUN OBIETTIVO TROVATO ===");
      log("⏳ Attesa 20 secondi...");
      await sleep(20000);
      return;
    }
    
    log(`\n=== FASE 3: CLICK SU ${obiettivi.length} OBIETTIVI ===`);
    
    for (let i = 0; i < obiettivi.length; i++) {
      const obj = obiettivi[i];
      const isLast = (i === obiettivi.length - 1);
      
      log(`📋 [${i + 1}/${obiettivi.length}] Obiettivo (Macro ${obj.macroIndex + 1}, Sotto ${obj.subIndex + 1})`);
      
      obj.lesson.root.scrollIntoView({ block: "center" });
      await sleep(300);
      click(obj.lesson.root);
      
      if (isLast) {
        log(`⏳ ULTIMO OBIETTIVO - Attesa ${AFTER_LAST_OBIETTIVO / 1000}s...`);
        await sleep(AFTER_LAST_OBIETTIVO);
      } else {
        log(`⏳ Attesa ${OBIETTIVO_WAIT / 1000}s...`);
        await sleep(OBIETTIVO_WAIT);
      }
    }
    
    log("✅ Tutti gli obiettivi processati!");
  };
  
  // ===========================
  //   FASE 4: VIDEO
  // ===========================
  const playLessons = async list => {
    log(`${list.length} video da processare`);
    
    for (let idx = 0; idx < list.length; idx++) {
      const l = list[idx];
      const pct = () => getProgress(l.root);
      const initialPct = pct();
      
      log(`[${idx + 1}/${list.length}] ${l.title.substring(0, 50)} - ${initialPct}%`);
      
      if (initialPct >= DONE) {
        log("Già completata");
        continue;
      }
      
      l.root.scrollIntoView({ block: "center" });
      await sleep(400);
      click(l.root);
      await sleep(2000);
      
      const video = await waitFor("#video", 20000);
      if (!video) {
        log("❌ Player non trovato");
        continue;
      }
      
      video.muted = true;
      
      let videoStarted = false;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          await video.play();
          video.playbackRate = PLAYBACK_SPEED;
          
          await sleep(1000);
          if (!video.paused && video.currentTime > 0) {
            log("✅ Video avviato");
            videoStarted = true;
            break;
          }
        } catch (e) {
          log(`⚠️ Tentativo play ${attempt + 1} fallito:`, e.message);
          await sleep(500);
        }
      }
      
      if (!videoStarted) {
        log("❌ Impossibile avviare il video, salto...");
        continue;
      }
      
      let dur = (video.duration && !isNaN(video.duration)) ? video.duration : getDuration(l.root);
      if (!dur || dur <= 0) dur = 60;
      
      const waitTime = (dur / PLAYBACK_SPEED * 1000) + EXTRA_BUFFER();
      log(`⏳ Attesa: ${(waitTime / 1000).toFixed(0)}s`);
      await sleep(waitTime);
      
      let waited = 0;
      const maxWait = Math.max(waitTime * 3, waitTime + 300000);
      
      while (pct() < DONE && waited < maxWait) {
        log(`📊 ${pct()}% - attendo...`);
        const stepWait = STEP_WAIT();
        await sleep(stepWait);
        waited += stepWait;
        
        if (video.paused) {
          log("⚠️ Video in pausa, riavvio...");
          try {
            await video.play();
            video.playbackRate = PLAYBACK_SPEED;
          } catch {}
        }
      }
      
      const finalPct = pct();
      if (finalPct >= DONE) {
        log(`✅ COMPLETATA ${finalPct}%`);
        log(`⏳ Attesa ${AFTER_VIDEO / 1000}s prima del prossimo video...`);
        await sleep(AFTER_VIDEO);
      } else {
        log(`⚠️ Timeout al ${finalPct}%`);
      }
    }
  };
  
  const executeTasks = async (tasks) => {
    if (tasks.length === 0) {
      log("\n=== FASE 4: NESSUN VIDEO MANCANTE ===");
      return;
    }
    
    log("\n=== FASE 4: ESECUZIONE VIDEO ===");
    
    for (let i = 0; i < tasks.length; i++) {
      const task = tasks[i];
      log(`\n📺 [${i + 1}/${tasks.length}] Macro ${task.macroIndex + 1} > Sotto ${task.subIndex + 1}`);
      
      task.subHeader.scrollIntoView({ block: "center" });
      await sleep(300);
      
      await playLessons(task.lessons);
    }
  };
  
  // ===========================
  //   FASE 5: TEST DI FINE LEZIONE
  // ===========================
  const completeTest = async (test) => {
    log(`📝 Test: ${test.lesson.title}`);
    
    test.lesson.root.scrollIntoView({ block: "center" });
    await sleep(500);
    
    // 1. Clicca "Esegui"
    const eseguiBtn = test.lesson.root.querySelector('button');
    if (!eseguiBtn || !eseguiBtn.textContent.includes('Esegui')) {
      log("❌ Pulsante 'Esegui' non trovato");
      return;
    }
    
    log("   1. Click su 'Esegui'");
    click(eseguiBtn);
    await sleep(5000); // Attesa 5s
    
    // 2. Trova tutte le domande e clicca risposta A
    log("   2. Rispondo a tutte le domande (risposta A)");
    
    // Le domande potrebbero essere in una sidebar o in un container
    const questions = document.querySelectorAll('[role="radio"], input[type="radio"]');
    
    if (questions.length === 0) {
      log("   ⚠️ Nessuna domanda trovata, cerco alternative...");
      
      // Cerca domande nel DOM visibile
      const questionContainers = document.querySelectorAll('div[class*="question"], .question-container');
      
      for (let i = 0; i < questionContainers.length; i++) {
        await sleep(1000); // 1 secondo tra una domanda e l'altra
        
        // Cerca la prima risposta (A) in ogni domanda
        const firstAnswer = questionContainers[i].querySelector('input[type="radio"], [role="radio"]');
        
        if (firstAnswer) {
          log(`      Domanda ${i + 1}: Click risposta A`);
          click(firstAnswer);
        }
      }
    } else {
      // Metodo alternativo: clicca il primo radio button di ogni gruppo
      const answeredGroups = new Set();
      
      for (let radio of questions) {
        const name = radio.name || radio.getAttribute('data-question-id');
        
        if (!answeredGroups.has(name)) {
          answeredGroups.add(name);
          await sleep(1000);
          log(`      Domanda "${name}": Click risposta A`);
          click(radio);
        }
      }
    }
    
    // 3. Attesa 3s e click su "Invia"
    log("   3. Attesa 3s prima di inviare...");
    await sleep(3000);
    
    const inviaBtn = document.querySelector('button:not([disabled])');
    const inviaButtons = Array.from(document.querySelectorAll('button')).filter(b => 
      b.textContent.trim().toUpperCase().includes('INVIA')
    );
    
    if (inviaButtons.length > 0) {
      log("   4. Click su 'Invia'");
      click(inviaButtons[0]);
    } else {
      log("   ⚠️ Pulsante 'Invia' non trovato");
    }
    
    // 4. Attesa 10s
    log(`   5. Attesa ${AFTER_TEST / 1000}s...`);
    await sleep(AFTER_TEST);
    
    log("   ✅ Test completato");
  };
  
  const executeTests = async (tests) => {
    if (tests.length === 0) {
      log("\n=== FASE 5: NESSUN TEST DA COMPLETARE ===");
      return;
    }
    
    log(`\n=== FASE 5: ESECUZIONE ${tests.length} TEST DI FINE LEZIONE ===`);
    
    for (let i = 0; i < tests.length; i++) {
      const test = tests[i];
      log(`\n📝 [${i + 1}/${tests.length}] Test (Macro ${test.macroIndex + 1}, Sotto ${test.subIndex + 1})`);
      
      await completeTest(test);
    }
  };
  
  // ===========================
  //   MAIN
  // ===========================
  const macros = await openEverything();
  const { allObiettivi, allVideoTasks, allTests } = await scanAll(macros);
  
  await completeObiettivi(allObiettivi);
  await executeTasks(allVideoTasks);
  await executeTests(allTests);
  
  log("\n🎉 ✓ COMPLETATO ✓ 🎉");
  clearState();
})();
