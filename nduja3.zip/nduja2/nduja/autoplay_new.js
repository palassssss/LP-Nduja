// AutoPlay per il nuovo player
console.log('🎬 Mercatorum AutoPlay - Player Nuovo Attivo');

let config = {
  autoplay: true,
  muted: false,
  autoNext: true
};

chrome.storage.local.get(['autoplay', 'muted', 'autoNext'], (result) => {
  config = { ...config, ...result };
  console.log('⚙️ Config caricata:', config);
  if (config.autoplay) {
    initAutoPlay();
  }
});

function initAutoPlay() {
  console.log('🚀 Inizializzazione AutoPlay (Nuovo Player)...');

  const checkVideo = setInterval(() => {
    const video = document.querySelector('video');
    
    if (video) {
      clearInterval(checkVideo);
      console.log('✅ Video trovato (nuovo player)!');
      
      // Imposta volume
      video.muted = config.muted;
      video.volume = config.muted ? 0 : 0.5;
      
      // Rimuovi overlay se presente
      const overlay = document.querySelector('.video-overlay');
      if (overlay) {
        overlay.remove();
        console.log('🗑️ Overlay rimosso');
      }

      // Avvia video
      setTimeout(() => {
        video.play().then(() => {
          console.log('▶️ Video avviato automaticamente');
        }).catch(err => {
          console.error('❌ Errore avvio video:', err);
          // Riprova dopo 1 secondo
          setTimeout(() => video.play(), 1000);
        });
      }, 500);

      // Listener fine video
      video.addEventListener('ended', () => {
        console.log('✅ Video terminato');
        if (config.autoNext) {
          setTimeout(goToNextVideo, 1000);
        }
      });

      // Listener errori
      video.addEventListener('error', (e) => {
        console.error('❌ Errore video:', e);
        if (config.autoNext) {
          setTimeout(goToNextVideo, 2000);
        }
      });
    }
  }, 500);

  setTimeout(() => clearInterval(checkVideo), 10000);
}

function goToNextVideo() {
  console.log('⏭️ Ricerca prossimo video (nuovo player)...');

  // Cerca container argomenti
  const argumentsContainer = document.querySelector('.arguments-container');
  if (!argumentsContainer) {
    console.log('❌ Container argomenti non trovato');
    return;
  }

  // Trova argomento corrente
  const currentArg = argumentsContainer.querySelector('.argument.active, .argument.current');
  
  if (currentArg) {
    // Cerca prossimo argomento
    let nextArg = currentArg.nextElementSibling;
    
    // Salta argomenti disabilitati
    while (nextArg && nextArg.classList.contains('disabled')) {
      nextArg = nextArg.nextElementSibling;
    }

    if (nextArg) {
      const nextLink = nextArg.querySelector('a');
      if (nextLink) {
        console.log('✅ Prossimo argomento trovato, navigazione...');
        nextLink.click();
        return;
      }
    }
  }

  // Alternativa: cerca nella lista laterale
  const sidebarItems = document.querySelectorAll('.sidebar-item a');
  const currentUrl = window.location.href;
  
  for (let i = 0; i < sidebarItems.length; i++) {
    if (sidebarItems[i].href === currentUrl || sidebarItems[i].classList.contains('active')) {
      if (sidebarItems[i + 1]) {
        console.log('📋 Prossimo dalla sidebar');
        sidebarItems[i + 1].click();
        return;
      }
    }
  }

  console.log('ℹ️ Fine corso - nessun video successivo');
}

// Indicatore visivo
const indicator = document.createElement('div');
indicator.innerHTML = '🤖 AutoPlay ATTIVO';
indicator.style.cssText = `
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #2196F3;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  font-family: Arial, sans-serif;
  font-size: 14px;
  font-weight: bold;
  z-index: 10000;
  box-shadow: 0 2px 5px rgba(0,0,0,0.3);
`;
document.body.appendChild(indicator);

setTimeout(() => {
  indicator.style.transition = 'opacity 0.5s';
  indicator.style.opacity = '0';
  setTimeout(() => indicator.remove(), 500);
}, 3000);